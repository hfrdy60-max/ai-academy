// Minimal IndexedDB wrapper (no library). Later milestones add stores via DB_VERSION upgrades.
const DB_NAME = "ai-academy";
const DB_VERSION = 1;
export const STORE_COURSES = "courses";

let dbPromise: Promise<IDBDatabase> | null = null;

export function openDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      dbPromise = null;
      reject(new Error("ذخیره‌سازی محلی (IndexedDB) در این مرورگر یا حالت مرور خصوصی در دسترس نیست."));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_COURSES)) db.createObjectStore(STORE_COURSES, { keyPath: "id" });
    };
    req.onsuccess = () => {
      const db = req.result;
      db.onversionchange = () => { db.close(); dbPromise = null; };
      resolve(db);
    };
    req.onerror = () => { dbPromise = null; reject(req.error ?? new Error("باز کردن پایگاه داده ناموفق بود.")); };
    req.onblocked = () => { dbPromise = null; reject(new Error("پایگاه داده توسط تب دیگری قفل شده است. سایر تب‌های برنامه را ببندید.")); };
  });
  return dbPromise;
}

/** Run one request and resolve only after the transaction is committed (so data really is saved). */
export async function withStore<T>(mode: IDBTransactionMode, run: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await openDb();
  return new Promise<T>((resolve, reject) => {
    const tx = db.transaction(STORE_COURSES, mode);
    let result!: T;
    const req = run(tx.objectStore(STORE_COURSES));
    req.onsuccess = () => { result = req.result; };
    tx.oncomplete = () => resolve(result);
    tx.onerror = () => reject(tx.error ?? new Error("عملیات ذخیره‌سازی ناموفق بود."));
    tx.onabort = () => reject(tx.error ?? new Error("عملیات ذخیره‌سازی لغو شد (شاید فضای ذخیره‌سازی پر است)."));
  });
}

/** Ask the browser not to evict our data when storage is low. Best effort; failure is harmless. */
export async function requestPersistence(): Promise<void> {
  try { await navigator.storage?.persist?.(); } catch { /* ignore */ }
}
