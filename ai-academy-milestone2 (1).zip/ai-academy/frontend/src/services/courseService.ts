import { deleteCourse, getCourse, listCourses, saveCourse } from "../database/courses";
import { fa } from "../lib/format";
import { newId } from "../lib/id";
import type { Chapter, Course, Level } from "../types/course";

export const LIMITS = { title: 100, subject: 100, description: 1000, goal: 500 } as const;

export interface NewCourseInput {
  title: string;
  description: string;
  subject: string;
  level: Level;
  goal: string;
  withSampleStructure: boolean;
}

export interface CourseProgress { done: number; total: number; percent: number }
export interface LessonRef { chapter: Chapter; lessonId: string; title: string }

interface Plan { title: string; lessons: string[] }

function buildChapters(plan: Plan[]): Chapter[] {
  return plan.map(c => ({
    id: newId(),
    title: c.title,
    lessons: c.lessons.map(t => ({ id: newId(), title: t, completed: false }))
  }));
}

// Placeholder structure until AI course generation exists (Milestone 4).
const genericPlan = (): Plan[] =>
  [1, 2, 3].map(c => ({
    title: `فصل ${fa(c)}`,
    lessons: [1, 2].map(l => `درس ${fa(l)} از فصل ${fa(c)}`)
  }));

export function courseProgress(c: Course): CourseProgress {
  const lessons = c.chapters.flatMap(ch => ch.lessons);
  const done = lessons.filter(l => l.completed).length;
  return { done, total: lessons.length, percent: lessons.length ? Math.round((done / lessons.length) * 100) : 0 };
}

/** Where "continue learning" should go: the lesson the learner stopped at, else the first unfinished one. */
export function nextLesson(c: Course): LessonRef | null {
  const flat: LessonRef[] = c.chapters.flatMap(ch => ch.lessons.filter(l => !l.completed).map(l => ({ chapter: ch, lessonId: l.id, title: l.title })));
  if (flat.length === 0) return null;
  return flat.find(x => x.lessonId === c.lastLessonId) ?? flat[0];
}

export function findLesson(c: Course, lessonId: string) {
  for (const chapter of c.chapters) {
    const lesson = chapter.lessons.find(l => l.id === lessonId);
    if (lesson) return { chapter, lesson };
  }
  return null;
}

export async function createCourse(input: NewCourseInput): Promise<Course> {
  const title = input.title.trim();
  const subject = input.subject.trim();
  const description = input.description.trim();
  const goal = input.goal.trim();
  if (!title) throw new Error("عنوان دوره را وارد کنید.");
  if (!subject) throw new Error("موضوع دوره را وارد کنید.");
  if (title.length > LIMITS.title) throw new Error(`عنوان نباید بیشتر از ${fa(LIMITS.title)} حرف باشد.`);
  if (subject.length > LIMITS.subject) throw new Error(`موضوع نباید بیشتر از ${fa(LIMITS.subject)} حرف باشد.`);
  if (description.length > LIMITS.description) throw new Error(`توضیحات نباید بیشتر از ${fa(LIMITS.description)} حرف باشد.`);
  if (goal.length > LIMITS.goal) throw new Error(`هدف یادگیری نباید بیشتر از ${fa(LIMITS.goal)} حرف باشد.`);
  const now = Date.now();
  const course: Course = {
    id: newId(), title, subject, description, goal, level: input.level,
    chapters: input.withSampleStructure ? buildChapters(genericPlan()) : [],
    isDemo: false, createdAt: now, updatedAt: now
  };
  await saveCourse(course);
  return course;
}

const DEMOS: { title: string; subject: string; level: Level; goal: string; description: string; plan: Plan[] }[] = [
  {
    title: "مبانی برنامه‌نویسی (نمونه آزمایشی)", subject: "برنامه‌نویسی", level: "beginner",
    goal: "آشنایی با مفاهیم پایه مثل متغیر، شرط و حلقه",
    description: "دوره نمونه برای آزمایش مدیریت دوره و ثبت پیشرفت. محتوای درس‌ها هنوز تولید نشده است.",
    plan: [
      { title: "فصل ۱: مفاهیم پایه", lessons: ["متغیر و نوع داده", "شرط‌ها", "حلقه‌ها"] },
      { title: "فصل ۲: تابع‌ها", lessons: ["تعریف تابع", "پارامتر و خروجی"] }
    ]
  },
  {
    title: "انگلیسی فنی مقدماتی (نمونه آزمایشی)", subject: "زبان انگلیسی", level: "beginner",
    goal: "خواندن دستورالعمل‌ها و برچسب‌های فنی ساده",
    description: "دوره نمونه برای آزمایش مدیریت دوره و ثبت پیشرفت. محتوای درس‌ها هنوز تولید نشده است.",
    plan: [
      { title: "فصل ۱: واژگان پایه", lessons: ["Tools and Parts", "Units and Measurements"] },
      { title: "فصل ۲: خواندن دستورالعمل", lessons: ["Safety Signs", "Following Instructions"] }
    ]
  }
];

/** Adds the sample courses that are not already stored. Returns how many were added. */
export async function seedDemoCourses(): Promise<number> {
  const existing = new Set((await listCourses()).filter(c => c.isDemo).map(c => c.title));
  let added = 0;
  for (const d of DEMOS) {
    if (existing.has(d.title)) continue;
    const now = Date.now() + added; // keep a stable order
    await saveCourse({
      id: newId(), title: d.title, subject: d.subject, level: d.level, goal: d.goal, description: d.description,
      chapters: buildChapters(d.plan), isDemo: true, createdAt: now, updatedAt: now
    });
    added++;
  }
  return added;
}

async function mustGet(id: string): Promise<Course> {
  const c = await getCourse(id);
  if (!c) throw new Error("این دوره پیدا نشد. ممکن است حذف شده باشد.");
  return c;
}

/** Remember where the learner is, so "continue learning" resumes here. */
export async function touchLesson(courseId: string, lessonId: string): Promise<Course> {
  const c = await mustGet(courseId);
  if (c.lastLessonId !== lessonId && findLesson(c, lessonId)) {
    c.lastLessonId = lessonId;
    c.updatedAt = Date.now();
    await saveCourse(c);
  }
  return c;
}

export async function completeLesson(courseId: string, lessonId: string): Promise<Course> {
  const c = await mustGet(courseId);
  const found = findLesson(c, lessonId);
  if (!found) throw new Error("این درس پیدا نشد.");
  if (!found.lesson.completed) { found.lesson.completed = true; found.lesson.completedAt = Date.now(); }
  c.lastLessonId = lessonId;
  c.updatedAt = Date.now();
  await saveCourse(c);
  return c;
}

export const removeCourse = (id: string): Promise<void> => deleteCourse(id);
export { listCourses, getCourse };
