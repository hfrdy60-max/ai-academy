import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import Icon from "../components/Icon";
import { useCourse } from "../hooks/useCourses";
import { errMsg } from "../lib/errors";
import { completeLesson, findLesson, nextLesson, touchLesson } from "../services/courseService";

export default function LessonPage() {
  const { courseId, lessonId } = useParams();
  const navigate = useNavigate();
  const { course, loading, error, setCourse } = useCourse(courseId);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Remember where the learner is so "continue learning" resumes here.
  useEffect(() => {
    if (!courseId || !lessonId) return;
    touchLesson(courseId, lessonId).catch(() => { /* non-critical */ });
  }, [courseId, lessonId]);

  if (loading) return <p className="muted" role="status">در حال بارگذاری…</p>;
  if (error) return <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-800 dark:bg-red-500/10 dark:text-red-200">{error}</p>;
  const found = course && lessonId ? findLesson(course, lessonId) : null;
  if (!course || !found) {
    return (
      <div className="card text-center">
        <h1 className="font-bold">درس پیدا نشد</h1>
        <Link to="/courses" className="btn btn-primary mt-4">بازگشت به دوره‌های من</Link>
      </div>
    );
  }

  async function finish() {
    if (!course || !lessonId) return;
    setSaving(true);
    setSaveError(null);
    try {
      const updated = await completeLesson(course.id, lessonId);
      setCourse(updated);
      const next = nextLesson(updated);
      navigate(next ? `/courses/${course.id}/lessons/${next.lessonId}` : `/courses/${course.id}`);
    } catch (e) {
      setSaveError(errMsg(e));
    } finally {
      setSaving(false); // the page stays mounted when moving to the next lesson
    }
  }

  const { chapter, lesson } = found;
  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <Link to={`/courses/${course.id}`} className="muted inline-flex min-h-11 items-center gap-1 text-sm hover:underline">
        <Icon name="back" className="h-4 w-4" />{course.title}
      </Link>
      <section className="card space-y-3">
        <p className="muted text-sm">{chapter.title}</p>
        <h1 className="text-xl font-extrabold md:text-2xl">{lesson.title}</h1>
        {course.goal && <div><h2 className="text-sm font-bold">هدف دوره</h2><p className="text-sm leading-7">{course.goal}</p></div>}
        <p className="rounded-xl bg-amber-50 p-3 text-sm leading-7 text-amber-900 dark:bg-amber-400/10 dark:text-amber-100">
          محتوای این درس هنوز تولید نشده است. تولید خودکار درس با هوش مصنوعی در نقطه عطف ۴ اضافه می‌شود. تا آن زمان فقط می‌توانید پیشرفت خود را ثبت کنید.
        </p>
        {saveError && <p role="alert" className="text-sm text-red-700 dark:text-red-300">{saveError}</p>}
        {lesson.completed ? (
          <div className="flex flex-wrap items-center gap-2">
            <span className="btn btn-ghost" role="status"><Icon name="check" className="h-4 w-4" />این درس تکمیل شده است</span>
            <Link to={`/courses/${course.id}`} className="btn btn-primary">بازگشت به دوره</Link>
          </div>
        ) : (
          <button type="button" className="btn btn-primary w-full sm:w-auto" disabled={saving} onClick={() => void finish()}>
            <Icon name="check" className="h-4 w-4" />{saving ? "در حال ذخیره…" : "تکمیل درس و ادامه"}
          </button>
        )}
      </section>
    </div>
  );
}
