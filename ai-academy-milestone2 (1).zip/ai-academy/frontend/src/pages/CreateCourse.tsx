import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { errMsg } from "../lib/errors";
import { fa } from "../lib/format";
import { createCourse, LIMITS } from "../services/courseService";
import { LEVELS } from "../types/course";
import type { Level } from "../types/course";

export default function CreateCourse() {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");
  const [goal, setGoal] = useState("");
  const [level, setLevel] = useState<Level>("beginner");
  const [sample, setSample] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: { preventDefault: () => void }) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    try {
      const course = await createCourse({ title, subject, description, goal, level, withSampleStructure: sample });
      navigate(`/courses/${course.id}`);
    } catch (err) {
      setError(errMsg(err));
      setSaving(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <h1 className="text-xl font-extrabold md:text-2xl">ساخت دوره جدید</h1>
      <p className="muted text-sm">
        در این نسخه، دوره به‌صورت دستی ساخته می‌شود. تولید خودکار برنامه درسی و محتوا با هوش مصنوعی در نقطه عطف ۴ اضافه می‌شود.
      </p>

      <form onSubmit={e => void submit(e)} className="card space-y-4" noValidate>
        <div>
          <label htmlFor="c-title" className="mb-1 block text-sm font-bold">عنوان دوره <span aria-hidden="true">*</span></label>
          <input id="c-title" className="input" value={title} maxLength={LIMITS.title} required aria-required="true"
                 onChange={e => setTitle(e.target.value)} placeholder="مثلاً: آشنایی با سیستم جرقه خودرو" />
        </div>
        <div>
          <label htmlFor="c-subject" className="mb-1 block text-sm font-bold">موضوع <span aria-hidden="true">*</span></label>
          <input id="c-subject" className="input" value={subject} maxLength={LIMITS.subject} required aria-required="true"
                 onChange={e => setSubject(e.target.value)} placeholder="مثلاً: برق خودرو" />
        </div>
        <div>
          <label htmlFor="c-level" className="mb-1 block text-sm font-bold">سطح آموزشی</label>
          <select id="c-level" className="input" value={level} onChange={e => setLevel(e.target.value as Level)}>
            {LEVELS.map(l => <option key={l.value} value={l.value}>{l.label}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="c-goal" className="mb-1 block text-sm font-bold">هدف یادگیری</label>
          <textarea id="c-goal" className="input" rows={3} value={goal} maxLength={LIMITS.goal}
                    onChange={e => setGoal(e.target.value)} placeholder="بعد از این دوره می‌خواهم بتوانم…" />
        </div>
        <div>
          <label htmlFor="c-desc" className="mb-1 block text-sm font-bold">توضیحات</label>
          <textarea id="c-desc" className="input" rows={3} value={description} maxLength={LIMITS.description}
                    onChange={e => setDescription(e.target.value)} />
          <p className="muted mt-1 text-xs">حداکثر {fa(LIMITS.description)} حرف</p>
        </div>
        <label className="flex min-h-11 items-start gap-3 text-sm">
          <input type="checkbox" className="mt-1 h-5 w-5" checked={sample} onChange={e => setSample(e.target.checked)} />
          <span>ایجاد ساختار آزمایشی (۳ فصل و ۶ درس با عنوان‌های کلی) تا بتوانید ثبت پیشرفت را امتحان کنید. محتوای درس‌ها بعداً با هوش مصنوعی ساخته می‌شود.</span>
        </label>

        {error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-800 dark:bg-red-500/10 dark:text-red-200">{error}</p>}

        <button type="submit" className="btn btn-primary w-full sm:w-auto" disabled={saving}>{saving ? "در حال ذخیره…" : "ذخیره دوره"}</button>
      </form>
    </div>
  );
}
